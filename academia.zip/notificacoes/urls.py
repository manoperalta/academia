from django.urls import path
from . import views

urlpatterns = [
    path('criar/', views.criar_notificacao, name='criar_notificacao'),
]
